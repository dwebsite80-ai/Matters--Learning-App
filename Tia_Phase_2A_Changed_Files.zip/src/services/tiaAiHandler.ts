import { GoogleGenAI } from '@google/genai';
import { getCourseScope } from './tiaCourseRegistry';
import { cleanTiaSpeechText } from './tiaLanguageConfig';
import { TiaLessonContext, TiaMessage } from '../types';

export function getGeminiApiKey(): string | undefined {
  const env = process.env;
  const rawKey =
    env.GEMINI_API_KEY ||
    env.VITE_GEMINI_API_KEY ||
    env.GOOGLE_GENAI_API_KEY ||
    env.GOOGLE_API_KEY ||
    env.API_KEY ||
    env.GEMINI_KEY ||
    env.gemini_api_key ||
    env.google_api_key;

  if (!rawKey) return undefined;
  let trimmed = rawKey.trim();

  // Strip surrounding single/double quotes if accidentally included in environment variable dashboard inputs
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    trimmed = trimmed.slice(1, -1).trim();
  }

  // Filter out placeholder template strings
  if (
    !trimmed ||
    trimmed === 'MY_GEMINI_API_KEY' ||
    trimmed === 'YOUR_API_KEY' ||
    trimmed.startsWith('MY_')
  ) {
    return undefined;
  }

  return trimmed;
}

let aiClient: GoogleGenAI | null = null;
let lastApiKey: string | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  const currentKey = getGeminiApiKey();
  if (!currentKey) {
    return null;
  }

  if (!aiClient || lastApiKey !== currentKey) {
    lastApiKey = currentKey;
    aiClient = new GoogleGenAI({
      apiKey: currentKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  return aiClient;
}

export interface TiaChatRequestBody {
  message?: string;
  question?: string;
  userText?: string;
  prompt?: string;
  text?: string;
  input?: string;
  context?: TiaLessonContext | null;
  course?: any;
  currentCourse?: any;
  lesson?: any;
  currentLesson?: any;
  relevantCourseContext?: any;
  mode?: string;
  language?: 'hi' | 'en';
  conversationHistory?: any[];
  history?: any[];
  messages?: any[];
}

export interface TiaChatResult {
  status: number;
  data: {
    ok: boolean;
    error?: string;
    code?: string;
    text?: string;
    answer?: string;
    displayText?: string;
    speechText?: string;
    quickActions?: string[];
    message?: TiaMessage;
  };
}

export async function processTiaChat(body: TiaChatRequestBody): Promise<TiaChatResult> {
  // 1. Extract question/message from any common parameter name
  const rawUserText =
    body.message ||
    body.question ||
    body.userText ||
    body.prompt ||
    body.text ||
    body.input ||
    '';
  const userText = String(rawUserText).trim();

  const hasKey = Boolean(getGeminiApiKey());
  console.log(`[Tia Backend] Question received: "${userText}" | Lang: ${body.language || 'hi'} | GEMINI_API_KEY present: ${hasKey}`);

  if (!userText) {
    return {
      status: 400,
      data: {
        ok: false,
        error: 'Message cannot be empty',
        code: 'EMPTY_MESSAGE',
      },
    };
  }

  const language = body.language === 'en' ? 'en' : 'hi';
  const isHindi = language === 'hi';

  // 2. Safely resolve course and lesson context (fully optional)
  let courseName = '';
  let courseDescription = '';
  let lessonTitle = '';

  // Check explicit course parameters or context
  const rawCourse =
    body.course ??
    body.currentCourse ??
    (isHindi ? body.context?.subjectName_hi || body.context?.subjectName : body.context?.subjectName);

  if (rawCourse && typeof rawCourse === 'string' && rawCourse.trim()) {
    courseName = rawCourse.trim();
  } else if (rawCourse && typeof rawCourse === 'object' && rawCourse.name) {
    courseName = String(rawCourse.name).trim();
    if (rawCourse.description) courseDescription = String(rawCourse.description).trim();
  } else if (body.context?.subjectId) {
    const scope = getCourseScope(body.context.subjectId, body.context);
    courseName = isHindi ? scope.name_hi || scope.name : scope.name;
    courseDescription = isHindi ? scope.description_hi || scope.description : scope.description;
  }

  const rawLesson =
    body.lesson ??
    body.currentLesson ??
    (isHindi ? body.context?.lessonTitle_hi || body.context?.lessonTitle : body.context?.lessonTitle);

  if (rawLesson && typeof rawLesson === 'string' && rawLesson.trim()) {
    lessonTitle = rawLesson.trim();
  } else if (rawLesson && typeof rawLesson === 'object' && rawLesson.title) {
    lessonTitle = String(rawLesson.title).trim();
  }

  // 3. Extract relevant course content / sections safely, capped to prevent payload bloat
  let relevantContentText = '';
  const rawSections = body.relevantCourseContext ?? body.context?.sections;
  if (Array.isArray(rawSections)) {
    relevantContentText = rawSections
      .slice(0, 5)
      .map((s) => {
        if (!s) return '';
        if (typeof s === 'string') return `• ${s}`;
        const title = isHindi ? s.title_hi || s.title : s.title;
        const content = isHindi ? s.content_hi || s.content : s.content;
        return `• ${title || ''}: ${content || ''}`;
      })
      .filter(Boolean)
      .join('\n');
  } else if (typeof rawSections === 'string') {
    relevantContentText = rawSections.slice(0, 800);
  }

  // Truncate relevant content to 800 characters maximum
  if (relevantContentText.length > 800) {
    relevantContentText = relevantContentText.slice(0, 800) + '...';
  }

  // 4. Extract conversation history safely (last 6 turns, up to 300 chars each)
  const rawHistory = body.conversationHistory || body.history || body.messages || [];
  const historyList: string[] = [];
  if (Array.isArray(rawHistory)) {
    const slice = rawHistory.slice(-6);
    for (const m of slice) {
      if (!m) continue;
      const sender = m.sender === 'user' || m.role === 'user' ? 'User' : 'Tia';
      const text = m.text || m.content || m.message || '';
      if (text) historyList.push(`${sender}: ${String(text).slice(0, 300)}`);
    }
  }
  const historyString = historyList.join('\n');

  // 5. Check Gemini client availability
  const gemini = getGeminiClient();
  if (!gemini) {
    console.warn(
      '[Tia AI] GEMINI_API_KEY is not configured in this environment.'
    );
    return {
      status: 500,
      data: {
        ok: false,
        error: 'GEMINI_API_KEY is not configured on the server',
        code: 'MISSING_API_KEY',
      },
    };
  }

  // 6. Build prompt instructions (Phase 2A Upgraded: Personality, Wit & Intelligence)
  const hasCourse = Boolean(courseName);

  const systemPrompt = `You are Tia (टिया), an exceptionally smart, witty, fun, and warm AI mentor on the Matters micro-learning platform.

CORE PERSONA & IDENTITY:
- You are that brilliant, lively senior or clever friend everyone wishes they had: quick-witted, deeply knowledgeable, genuinely encouraging, with an infectious sense of humor and crisp real-world analogies.
- You speak with authentic personality, playful charm, and zero robotic corporate stiffness ("academic monotone" is strictly forbidden!).
- You treat learners as smart, capable peers. Use relatable everyday scenarios (chai discussions, smartphone dilemmas, office drama, street-smart examples, cricket moments, college banter).

CARDINAL RULES (ABSOLUTE HIGHEST PRIORITY):
1. USER'S LATEST QUERY HAS SUPREME PRIORITY:
   - Always answer the user's latest question directly, accurately, and thoroughly first.
   - You are a UNIVERSAL AI MENTOR. You answer ANY subject: philosophy, coding, general knowledge, current events, history, pop culture, life dilemmas, cooking, science, cricket, or business case studies.
   ${hasCourse ? `- ACTIVE COURSE CONTEXT: "${courseName}" is merely context/background for where the user is currently browsing. It is NEVER a restriction or boundary! If the user's question relates to ${courseName}, illuminate it brilliantly. If the user asks something completely outside ${courseName}, answer their question enthusiastically with full depth. Only connect back to ${courseName} if it feels 100% natural and witty—never force an artificial connection.` : '- GENERAL MODE: Answer any topic without constraints.'}
   - FORBIDDEN REJECTIONS (NEVER EVER SAY):
     × "This is outside your course."
     × "This question is not related to your syllabus."
     × "I can only answer course-related questions."
     × "Please ask something about the current lesson."
     Tia NEVER refuses or gates a user's question!

2. HUMOR, WIT & CONVERSATIONAL CHARM:
   - Begin with a delightful, witty, or lively opening hook.
   - Use smart, lighthearted punchlines and grounded everyday analogies.
   - If the user cracks a joke or makes a playful comment, match their energy with sharp, good-natured banter.
   - If the user asks a serious or deep question, provide rigorous, insightful substance wrapped in engaging, lucid language.

3. ANSWER ARCHITECTURE & STRUCTURE:
   - Structure: 2 to 3 well-crafted, punchy paragraphs.
   - Opening Hook: Catch attention with wit, relatable contrast, or clear perspective.
   - Core Insight: Crystal-clear reasoning, real-world examples, or actionable mental models.
   - Memorable Takeaway: A witty summary or provocative thought that makes the lesson stick.
   - Keep formatting clean: use markdown bolding (**key concepts**) naturally for visual skimming. Avoid wall-of-text lists.

4. QUICK ACTIONS:
   - Provide 2 to 3 creative, genuinely tempting follow-up prompts.
   - Examples of engaging quick actions: "💡 Ek desi example do", "😂 Thoda aur roast karo", "🔍 Iska real-life hack kya hai?", "🤔 Iska counter-argument kya hai?"
   ${hasCourse ? `- Include one natural option to transition back to ${courseName} (e.g., "📖 ${courseName} par wapas chalein").` : ''}

5. BILINGUAL EXCELLENCE (HINDI & ENGLISH DUAL-OUTPUT RULES):
   - Active Language: ${isHindi ? 'Hindi' : 'English'}
   ${isHindi ? `- HINDI OUTPUT SPECIFICATIONS:
     • displayText: Natural, friendly, expressive Hindi / Hinglish written in clean script or romanized terms where natural. Use markdown bolding (**शब्द**) for key terms so it looks crisp on mobile.
     • speechText: PURE NATURAL SPOKEN HINDI strictly written in DEVANAGARI SCRIPT (देवनागरी) for the hi-IN text-to-speech voice synthesizer.
       - Conversational Hindi words MUST be in Devanagari (e.g., "नमस्ते", "यह सवाल बहुत बढ़िया है", "सोच कर देखो").
       - Standard English proper nouns and technical terms can remain in English or Devanagari (e.g., "Python", "GDP", "Virat Kohli", "Airbnb").
       - STRICT SPEECH CLEANLINESS: DO NOT include asterisks (*), hashtags (#), bullet points (•), markdown tags, emojis, or URLs in speechText. Write smooth, fluid sentences that sound natural when spoken aloud.` : `- ENGLISH OUTPUT SPECIFICATIONS:
     • displayText: Fluent, sharp, witty, articulate English with markdown bolding (**concepts**) for easy reading.
     • speechText: Natural conversational spoken English without asterisks (*), markdown formatting, hashtags, or emojis.`}

OUTPUT FORMAT:
Return ONLY a valid JSON object with this exact schema (no outer conversational text, no markdown backticks):
{
  "displayText": "Visually formatted text for mobile display with bolding and markdown",
  "speechText": "Spoken text specifically optimized for TTS engine without symbols or emojis",
  "quickActions": ["Action 1", "Action 2", "Action 3"]
}`;

  const userContextPrompt = `${hasCourse ? `ACTIVE_COURSE: ${courseName} ${courseDescription ? `(${courseDescription})` : ''}\n` : ''}${lessonTitle ? `ACTIVE_LESSON: ${lessonTitle}\n` : ''}${relevantContentText ? `COURSE_CONTEXT:\n${relevantContentText}\n` : ''}${historyString ? `RECENT_CONVERSATION:\n${historyString}\n` : ''}USER_LATEST_QUESTION (HIGHEST PRIORITY): "${userText}"
TARGET_LANGUAGE: ${isHindi ? 'Hindi (speechText in pure Devanagari script for hi-IN TTS)' : 'English'}`;

  const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  // High-availability model cascade: gemini-3.1-flash-lite has optimal throughput & lowest latency, with flash-latest and 3.8-flash as resilient fallbacks
  const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
  let response: any = null;
  let lastGeminiError: any = null;

  for (let i = 0; i < modelsToTry.length; i++) {
    const modelName = modelsToTry[i];
    console.log(
      `[Tia Backend] Gemini request started | Model: ${modelName} | Question: "${userText.slice(0, 80)}" | Prompt length: ${userContextPrompt.length}`
    );

    try {
      response = await gemini.models.generateContent({
        model: modelName,
        contents: userContextPrompt,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.75,
          maxOutputTokens: 1500,
          responseMimeType: 'application/json',
        },
      });

      if (response?.text) {
        console.log(
          `[Tia Backend] Gemini response received | Model: ${modelName} | Length: ${response.text.length}`
        );
        break;
      }
    } catch (err: any) {
      lastGeminiError = err;
      const status = err?.status || err?.code;

      // Fast fail on auth error immediately
      if (
        status === 400 ||
        status === 401 ||
        status === 403 ||
        err?.message?.includes('API key not valid') ||
        err?.message?.includes('API_KEY_INVALID')
      ) {
        console.error(
          `[Tia AI] Authentication error with Gemini API: ${err?.message || err}`
        );
        return {
          status: 401,
          data: {
            ok: false,
            error: `Gemini API authentication failed: ${err?.message || 'Invalid API key'}`,
            code: 'AUTH_FAILED',
          },
        };
      }

      if (i < modelsToTry.length - 1) {
        console.log(
          `[Tia AI] Model ${modelName} temporary issue (status: ${status}); failing over to next model...`
        );
        await sleep(250);
      } else {
        console.error(
          `[Tia AI] All models failed | Final model: ${modelName} | Status: ${status} | Error: ${err?.message || err}`
        );
      }
    }
  }

  let generatedDisplayText = '';
  let generatedSpeechText = '';
  let quickActions: string[] = [];

  if (response?.text) {
    const rawText = response.text.trim();
    let parsedDisplay = '';
    let parsedSpeech = '';
    let parsedActions: string[] = [];

    const cleanJson = rawText
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/```\s*$/i, '')
      .trim();

    try {
      const parsed = JSON.parse(cleanJson);
      if (parsed && typeof parsed === 'object') {
        parsedDisplay = parsed.displayText || parsed.text || '';
        parsedSpeech = parsed.speechText || '';
        if (Array.isArray(parsed.quickActions)) {
          parsedActions = parsed.quickActions.filter(Boolean);
        }
      }
    } catch {
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          parsedDisplay = parsed.displayText || parsed.text || '';
          parsedSpeech = parsed.speechText || '';
          if (Array.isArray(parsed.quickActions)) {
            parsedActions = parsed.quickActions.filter(Boolean);
          }
        } catch {
          // ignore
        }
      }

      // Regex fallback for partially truncated JSON
      if (!parsedDisplay) {
        const displayMatch = rawText.match(/"displayText"\s*:\s*"((?:\\.|[^"\\])*)"/s);
        if (displayMatch && displayMatch[1]) {
          try {
            parsedDisplay = JSON.parse(`"${displayMatch[1]}"`);
          } catch {
            parsedDisplay = displayMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
          }
        }

        const speechMatch = rawText.match(/"speechText"\s*:\s*"((?:\\.|[^"\\])*)"/s);
        if (speechMatch && speechMatch[1]) {
          try {
            parsedSpeech = JSON.parse(`"${speechMatch[1]}"`);
          } catch {
            parsedSpeech = speechMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
          }
        }
      }
    }

    if (!parsedDisplay) {
      // If rawText starts with JSON bracket, strip it
      let fallbackText = rawText;
      if (fallbackText.startsWith('{') && fallbackText.includes('"displayText"')) {
        const idx = fallbackText.indexOf('"displayText"');
        const colonIdx = fallbackText.indexOf(':', idx);
        if (colonIdx !== -1) {
          fallbackText = fallbackText.slice(colonIdx + 1).replace(/^[\s"]+/, '');
          const quoteIdx = fallbackText.indexOf('",');
          if (quoteIdx !== -1) {
            fallbackText = fallbackText.slice(0, quoteIdx);
          }
        }
      }
      parsedDisplay = fallbackText.replace(/\\n/g, '\n').replace(/\\"/g, '"');
      parsedSpeech = cleanTiaSpeechText(parsedDisplay, isHindi);
    }

    if (parsedDisplay && parsedDisplay.trim().length > 3) {
      generatedDisplayText = parsedDisplay.trim();
      generatedSpeechText = cleanTiaSpeechText(parsedSpeech || parsedDisplay, isHindi);
      quickActions = parsedActions;
    }
  }

  if (!generatedDisplayText) {
    console.warn('[Tia AI] Generation produced no text; returning 503 unavailable');
    return {
      status: 503,
      data: {
        ok: false,
        error: lastGeminiError?.message || 'Gemini AI service temporarily unavailable',
        code: 'AI_UNAVAILABLE',
      },
    };
  }

  if (quickActions.length === 0) {
    quickActions = isHindi
      ? hasCourse
        ? ['💡 देसी उदाहरण दो', '😂 थोड़ा और मज़ाकिया बनाओ', `📖 वापस ${courseName} पर चलें`]
        : ['💡 देसी उदाहरण दो', '😂 थोड़ा और मज़ाकिया बनाओ', '🎯 एक झटपट क्विज़ पूछो']
      : hasCourse
        ? ['💡 Give a fun example', '😂 Make it even wittier', `📖 Back to ${courseName}`]
        : ['💡 Give a fun example', '😂 Make it even wittier', '🎯 Ask me a quick quiz'];
  }

  const messagePayload: TiaMessage = {
    id: `tia-resp-${Date.now()}`,
    sender: 'tia',
    text: generatedDisplayText,
    speechText: generatedSpeechText,
    timestamp: Date.now(),
    quickActions,
  };

  return {
    status: 200,
    data: {
      ok: true,
      text: generatedDisplayText,
      answer: generatedDisplayText,
      displayText: generatedDisplayText,
      speechText: generatedSpeechText,
      quickActions,
      message: messagePayload,
    },
  };
}
